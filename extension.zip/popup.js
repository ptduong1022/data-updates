chrome.storage.local.get(['lastScanDate', 'lastUpdateDate', 'version'], (result) => {
  if (result.lastScanDate) {
    document.getElementById('lastScanTime').textContent = result.lastScanDate;
  } else {
    document.getElementById('lastScanTime').textContent = "Running...";
  }

  const ver = result.version || "2.8.2";
  const updateTime = result.lastUpdateDate || "Just now";
  document.getElementById('versionText').textContent = `Version ${ver} | Updated: ${updateTime}`;
});